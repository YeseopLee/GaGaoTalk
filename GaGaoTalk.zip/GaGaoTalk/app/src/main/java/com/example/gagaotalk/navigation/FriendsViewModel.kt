package com.example.gagaotalk.navigation

import androidx.lifecycle.ViewModel

class FriendsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
